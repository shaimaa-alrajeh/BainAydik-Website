function Btn(){
    return(
        <div class="pt-12 pb-8">
                <button class="border-2 border-[#2E90EB] transition-transform duration-200 ease-in-out hover:scale-[1.03] text-white font-bold py-2 px-4 rounded-md">
                    Download App
                </button>
        </div>
    )
}
export default Btn