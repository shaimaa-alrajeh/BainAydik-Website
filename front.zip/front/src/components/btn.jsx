function Btn(){
    return(
        <div class="pt-12 pb-8">
                <button class="bg-[#2E90EB] transition-transform duration-200 ease-in-out hover:scale-[1.03] text-white font-bold py-2 px-4 rounded-md">
                        Join us
                </button>
        </div>
    )
}
export default Btn